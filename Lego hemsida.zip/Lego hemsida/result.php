<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About</title>
  <script src="effect.js" defer></script>
</head>

<body class="Search"> 

  <div id="header">
       <div class="header container">
          <div class="nav-bar">
              <div class="brand">
                 <a href="index.html"><img src="bilder/legologo4.0.png" alt="Logo" id ="logo"></a>
              </div>

             <div class="menu" onclick="showMenu()"><div class="bar"></div></div> <!-- Side navbar -->

              <div class="nav-pages">
                 <ul>
                  <li><a href="index.html" class="Home">Home</a></li>
                  <li><a href="about.html" class="About">About</a></li>
                  <li><a href="search.html" class="Search">Search</a></li>
                 </ul>
              </div>
              <div class="nav-links" id="navLinks">
                 <ul>
                   <li><a href="index.html" class="Home">Home</a></li>
                   <li><a href="about.html" class="About">About</a></li>
                   <li><a href="search.html" class="Search">Search</a></li>
                 </ul>
               </div>
           </div>
       </div>
   </div>

   <form class= "form" action = "search.php" method ="POST" > <!-- Search bar-->
       <h1 class= "rubrik">SEARCH</h1> 

        <select name="selectedValue" id="options">
            <option value="Set-id">Set-id</option>
            <option value="Set-name">Set-name</option>
        </select>
              <label> [MENU]</label> <br> <!-- Menu to search either Set-id or Set-name -->
              <input type="text" name = "text" placeholder = "Write the input here" id = "text1" required>
         
          <input type="submit" value = "Submit" id="submit"> <!--submit button to send input to result.php -->
    </form> 

    <button onclick="hiddenbox()">  <!-- Info box button-->
      <i id="info" class="fa fa-info-circle"></i>
    </button>

    <div id="infobox"> <!-- Info box text -->
      <p> Step 1: Choose input type set-id or set-name in the dropdown menu.<br><br> Step 2: Enter name/id of your choice and press submit or press enter key.
        <br><br> Step 3: Click on the desired set image you want to browse to enter its page.
        <br><br> Step 4: If the desired set is not shown, check input once more for incorrect typing.
        <br><br> Tips: Common mistake is a space before the word/set-id in the searchbar.
      </p>
    </div>

    <!-- Function for side navbar-->
   <script> 
      var navLinks = document.getElementById("navLinks");
      var show = false;
       
        function showMenu() {
         show = !show;
            if (show) {
                navLinks.style.right = "0";
            } 
            else {
                navLinks.style.right = "-200px";
               
            }
        }
    </script>   
 <!-- The end tag for body and html is at the bottom of this page. Below the php.-->
<?php
 # To include the html with the navbar and search function


//connection to the database
$connection = mysqli_connect("mysql.itn.liu.se", "lego", "", "lego");

 //if the connection fails give error
if ($connection->connect_error) {

  die("Connection failed: " . $conn->connect_error);
}

//taking the set value from the url
$SetID = $connection -> real_escape_string($_GET['set']); 
//taking the setname to display it later
$setname  = mysqli_query($connection, "SELECT sets.Setname FROM sets WHERE sets.SetID= '$SetID'");
$nameArray = mysqli_fetch_array($setname);
$setnamedisplay = $nameArray['Setname'];

//searching for the info we need with the set id we got from our url
$info = mysqli_query($connection, "SELECT inventory.Quantity, inventory.SetID , inventory.ItemID, parts.Partname, images.ItemID, images.ItemtypeID,images.ColorID,
images.has_gif, images.has_jpg, images.has_largegif, images.has_largejpg, colors.Colorname
FROM inventory, colors, images, parts
WHERE
inventory.SetID = '$SetID'AND colors.ColorID=inventory.ColorID AND images.ItemID=inventory.ItemID AND images.ColorID=inventory.ColorID
AND images.ItemtypeID=inventory.ItemtypeID AND parts.PartID=inventory.ItemID ORDER BY inventory.Quantity DESC");
  

echo(//print out the table head of the info we display
  "<h3 class='mycss'>  Parts included in set $SetID ($setnamedisplay): </h3>
  <table>
    <tr>
     <td>Image</td>
     <td> part name </td>
     <td> Color </td>
     <td> Quantity </td>
    </tr>
  </table>"
);


//making a loop for as long as there are rows left
while   ($row =  mysqli_fetch_array($info)){
 $invpart = $row['Partname'];
 $invqual = $row['Quantity'];
 $colorsname = $row['Colorname'];
 $itemid = $row['ItemID'];
 $itemtype = $row['ItemtypeID'];
 $colorid = $row['ColorID'];
 $gif = $row['has_gif'];
 $jpg = $row['has_jpg'];
 $imagesrc = "";

 if ($jpg){
    $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/$itemtype/$colorid/$itemid.jpg" ;
  }

  else if ($gif){
    $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/$itemtype/$colorid/$itemid.gif";
  }

 echo (//print out the values
   "<table >
     <tr >
     <td> <img src= $imagesrc alt=Lego> </td>
     <td> $invpart </td>
     <td> $colorsname </td>
     <td> $invqual </td>
     </tr>
   </table>"
  ) ;
}
?>
 </body> <!--  The validator said there is no body or html end tag at the bottom. 
We had included the php at the start. The program read the body and html end tag before the h3 at line 114 in this php. 
It thought the h3 was outside the HTML so gave the error. 
this is a simple fix to the error, but it is ugly compared to our search.php. Which somehow works with the include function of our search.html. 
Weirdly, this result.php can't handle the include correctly.-->
</html>     