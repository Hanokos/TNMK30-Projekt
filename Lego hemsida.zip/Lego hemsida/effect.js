function inspectSet(setID) { // To send the user inputs to the url then to result.php
    window.location.href = "../Lego%20hemsida/result.php?set=" + setID;
}

function hiddenbox() { // Infobox button function
    var x = document.getElementById("infobox");
    if ( x.style.display =="block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
  }

