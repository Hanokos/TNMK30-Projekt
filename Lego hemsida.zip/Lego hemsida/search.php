<?php
include("search.html"); # To include the html with the navbar and search function

switch($_POST['selectedValue']){ # Case when user use the set-id menu option to search

 case 'Set-id':

    $connection = mysqli_connect("mysql.itn.liu.se", "lego", "", "lego");
 if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
 }

//taking the enter id from text
$SetID = $connection -> real_escape_string ($_POST['text']);
   
$query = "SELECT * FROM sets WHERE SetID = '$SetID'";
   
   //searching for info matching the id, here we  use LIKE steps to get more options since its hard to remember the whole id
    $searchid = mysqli_query($connection, "SELECT sets.SetID, images.has_largejpg, images.has_largegif, images.has_jpg, images.has_gif FROM sets, images
    WHERE sets.SetID LIKE '%$SetID%' AND images.ItemtypeID = 'S' AND images.ItemID = sets.SetID
    ORDER BY CASE
    WHEN sets.SetID LIKE '$SetID%' THEN 1
    WHEN sets.SetID LIKE '%$SetID' THEN 2
    ELSE 3
    END");
   
while($row = mysqli_fetch_array($searchid)){  
            $set_name = $row['Setname'];
            $setid1 = $row['SetID'];
            $itemid = $row['ItemID'];
            $gif = $row['has_gif'];
            $jpg = $row['has_jpg'];
            $gifL = $row['has_largegif'];
            $jpgL = $row['has_largejpg'];

           //checking for the image type
 $gifL = $row['has_largegif'];
 if ($jpgL){
         $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/SL/$setid1.jpg";
}
 else if  ($jpg){
     $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/SL/$setid1.gif";  
}   
 else {
         $imagesrc = "bilder/QuestionMark.png";
}
        //printing out the search term that match
        print(
            "<div class='setWrapper'>
             <div ><img src= $imagesrc class = 'nameimg' onclick='inspectSet(this.id)'  id='$setid1' >
             <p>$itemid </p>
             <p>$set_name</p>
             <p>Set ID: $setid1</p>
             </div>
             </div>");
}
    break;
    //we take the second case when the user wants to enter set-name    
    case 'Set-name':
         //connecting to the database
    $connection = mysqli_connect("mysql.itn.liu.se", "lego", "", "lego");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//we take the input of post and give it a value in setname
$setname = $_POST['text'];

$query = "SELECT * FROM sets WHERE Setname = '$setname'";

$result = mysqli_query($connection,  $query);
//here we get all the info that matches our search for the name and since we want to get info close to the search we use LIKE statments with both starting 
$searchname = mysqli_query($connection, "SELECT sets.SetID, sets.Setname, images.has_largejpg, images.has_largegif, images.has_jpg, images.has_gif FROM sets, images
WHERE sets.Setname LIKE '%$setname%' AND images.ItemtypeID = 'S' AND images.ItemID = sets.SetID ORDER BY CASE
WHEN sets.Setname LIKE '$setname' THEN 0
WHEN sets.Setname LIKE '$setname%' THEN 1
WHEN sets.Setname LIKE '%$setname%' THEN 2
WHEN sets.Setname LIKE '%$setname' THEN 3
ELSE 4
END");

//doing a while for as long as there are rows 
while($row = mysqli_fetch_array($searchname)){
         
        $set_name = $row['Setname'];
        $setid1 = $row['SetID'];
        $itemid = $row['ItemID'];
        $gif = $row['has_gif'];
        $jpg = $row['has_jpg'];
        $gifL = $row['has_largegif'];
        $jpgL = $row['has_largejpg'];
       $gifL = $row['has_largegif'];
 if ($jpgL){
    $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/SL/$setid1.jpg";
}
else if  ($jpg){
    $imagesrc = "http://www.itn.liu.se/~stegu76/img.bricklink.com/SL/$setid1.gif";  
}
else {
    $imagesrc = "bilder/QuestionMark.png";
}
 //print out all the sets we find matching to the search name          
print(
"<div class='setWrapper'>
 <div ><img src= $imagesrc class = 'nameimg' onclick='inspectSet(this.id)'  id='$setid1' >
 <p>$itemid </p>
 <p>$set_name</p>
 <p>Set ID: $setid1</p>
 </div>
 </div>");

   }
    break;
    default:
        // Something went wrong or form has been tampered.
}
?>